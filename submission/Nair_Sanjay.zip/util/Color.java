package util;

/**
 * Enum used to define color in Nodes.
 * 
 * @author Sanjay Nair
 *
 */
public enum Color {
	RED, BLACK
}
